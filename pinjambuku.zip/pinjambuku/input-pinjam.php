<?php
session_start();

if( !isset($_SESSION["login"])) {
  header("Location: login.php");
  exit;
}

require 'config.php';


  if(isset($_POST["simpan"])){

    if(tambah($_POST) > 0){
      echo"
      <script>
      alert('data ditambahkan!');
      document.location.href = 'data-pinjam.php';
      </script>
      ";
    } else {
      echo "
      <script>
      alert('data gagal ditambahkan');
      document.location.href = 'data-pinjam.php';
      </script>
      ";
    }
    }
       ?>

<!doctype html>
<html lang="en">
<?php include 'navbar.php';?>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css"/>
    <link rel="stylesheet" href="css/bootstrap-datepicker.min.css"/>
    <link rel="stylesheet" href="css/style.css">
    <link href="fontawesome/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="css/sweetalert2.min.css">
    <title>Pinjam Buku</title>
  </head>


  <body>
  <div id="none">
  <div class="table-responsive mt-2">
              <tr style="text-align: center; height : 25px;">
              <div class="table-responsive mt-2">
        <div class="card">
            <div class="card-header bg-secondary text-white">
            <h3 class="card-title">Formulir Peminjaman Buku</h3>
           silahkan isi formulir dibawah sebelum meminjam buku
                <tr>
  </div>
        <div class="container mt-3">
            <div class="card mt-3">
            <div class="card-body">
  <form action="" method="POST">
                <div class="mb-3 row">
                <label for="nama" class="col-sm-2 col-form-label">Nama Siswa</label>
                 <div class="col-sm-10">
                <input type="text" name="nama" id="nama" class="form-control" autocomplete="off" placeholder="Nama">
                </div>
                </div>

                <div class="mb-2 row">
                <label for="kelas" class="col-sm-2 col-form-label">Kelas</label>
                 <div class="col-sm-10">
                <input type="text" name="kelas" id="kelas" class="form-control" autocomplete="off" placeholder="Kelas">
                </div>
                </div>

                <div class="mb-2 row">
                <label for="telp" class="col-sm-2 col-form-label">No Telepon</label>
                <div class="col-sm-10"> 
                <input type="text" name="telp" id="telp" class="form-control" autocomplete="off" placeholder="No Telepon">
                </div>
                </div>
                  
                <div class="mb-2 row">
                <label for="tanggal_pinjam" class="col-sm-2 col-form-label">Tanggal Peminjaman</label>
                 <div class="col-sm-10">
                <input type="date" name="tanggal_pinjam" id="tanggal_pinjam" class="form-control">
                </div>
                </div>

                <div class="mb-2 row">
                <label for="judul_buku" class="col-sm-2 col-form-label">Judul Buku</label>
                 <div class="col-sm-10">
                <input type="text" name="judul_buku" id="judul_buku" class="form-control" autocomplete="off" placeholder="Judul Buku">
                </div>
                </div>

                <div class="mb-2 row">
                <label for="jumlah_buku" class="col-sm-2 col-form-label">Jumlah Buku</label>
                 <div class="col-sm-10">
                <input type="text" name="jumlah_buku" id="jumlah_buku"class="form-control" autocomplete="off" placeholder="Jumlah Buku">
                </div>
                </div>

                <div class="mb-2 row">
                <label for="jenis_buku" class="col-sm-2 col-form-label">Jenis Buku</label>
                 <div class="col-sm-10">
                <input type="text" name="jenis_buku" id="jenis_buku"class="form-control" autocomplete="off" placeholder="Jenis Buku">
                </div>
                </div>
                   
                   <div class="col-15 mt-3">
                        <input type="submit" name="simpan" value="simpan" class="btn btn-primary"/>
                        <input type="reset" name="batal" value="batal" class="btn btn-danger"/>
                        </div>
                </form>
            </div>
        </div>
</div>
            <br><br>
        </div>
    </div>
 
  
    