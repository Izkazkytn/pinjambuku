<?php

include 'config.php';
$pinjambuku = query("SELECT * FROM pinjambuku");
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link href="fontawesome/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="css/sweetalert2.min.css">
    <script src="js/sweetalert2.min.js"></script>
    <title>Web Pinjam Buku</title>
  </head>
  <body>
        <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #fff;">
        <div class="container">
        <a class="navbar-brand" href="#">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="btn btn-primary btn-sm rounded-pill mt-1" href="login.php" tabindex="-1" aria-disabled="true"> Login </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="beranda.php">Beranda <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="input-pinjam.php">Pinjam Buku</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="data-pinjam.php" tabindex="-1" aria-disabled="true">Data Peminjaman</a>
            </li>
            <li class="nav-item">
                <a class="btn btn-primary btn-sm rounded-pill mt-1" href="logout.php" tabindex="-1" aria-disabled="true"> Logout </a>
            </li>
            </ul>
        </div>
        </div>
        </nav>
        <div class="container">
        <div class="cover-img">
            <img src="IMG_9982.jpg" alt="13261">
        </div>
            <h1 class="page-one">Selamat Datang</h1>
            <h1 class="page-one-2" > ini adalah sebuah web aplikasi super sederhana untuk mengisi formulir peminjaman buku di perpustakaan SMKN4 BOGOR. Silahkan registrasi atau login terlebih dahulu.</h1>
            <div class="login-btn">
                    <a href="registrasi.php" class="btn-login">registrasi</a>
                </div>
            </div>
        </div>

    <script src="js/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <script defer src="fontawesome/js/all.js"></script>
  </body>
</html>