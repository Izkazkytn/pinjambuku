
 <?php
 session_start();

 if( !isset($_SESSION["login"])) {
   header("Location: login.php");
   exit;
 }

 
  error_reporting(0);
  session_start();

    include 'code crud/config.php';
	if (mysqli_connect_errno()) 
	{ 
		echo "Database connection failed."; 
	} 

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/sweetalert2.min.css">
    <title>Beranda</title>
  </head>
  <body>
    <div id="none">
    <?php include 'navbar.php';?>
    <br><br>
    <div class="container">
          <div class="row">
              <div class="col-lg-12">
                  <div class="container">
                  <h1 class="mt-2 p-3 text-center" style="color:black"> Website Pengisian Form Pinjam Buku SMKN 4 BOGOR </h1>
                  <p class="lead text-center" style="font-family: monospace;">"Write to be understood, speak to be heard, read to be grow."</p>    
                  </div>
              </div>
              <div class="cover-img">
            <img src="fotoberanda.jpg"  style="width:900px;height900px;">
        </div>
            </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <script src="js/sweetalert2.min.js"></script>
    
    