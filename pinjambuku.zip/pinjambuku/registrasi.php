<?php
require 'config.php';

if( isset($_POST["register"]) ) {

    if( registrasi($_POST) > 0) {
        echo "<script>
                alert('kamu berhasil terdaftar');
                </script>";
    }else{ 
        echo mysqli_error($koneksi);
    }            
    }
    ?>
 <!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/sweetalert2.min.css">
    <title>registrasi</title>
  </head>
  <body style="background-image: url(gradient.jpg); background-size: cover;">
    <div class="container">
      <div class="card mt-5 shadow" style="border-radius: 20px;">
        <div class="card-body">
          <div class="row img-login">
            <div class="col">
            <img src="login.jpg" alt="" class="float-left">
            </div>
               <div class="col">
                   <div class="form-login">
<form action="" method="POST">
<h1> Registrasi </h1>
        <div class="form-group mt-5">
                    <label for="username">username </label>
                    <input type="text" name="username" class="form-control" autocomplete="off">
                        </div>
                    <div class="form-group mt-4">
                    <label for="password">password </label>
                    <input type="password" name="password" class="form-control" autocomplete="off">
                        </div>
                        <div class="form-group mt-4">
                        <label for="password">konfirmasi password </label>
                    <input type="password" name="password2" class="form-control" autocomplete="off">
                        </div>
                        <div class="form-group mt-4">
                            <input type="submit" name="register" id="btn-login" class="btn btn-primary" value="Regist">
                        </div>
                        </form>
              </div>
             </div>
          </div>
        </div>
      </div>
    </div>
    <script src="js/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <script src="js/sweetalert2.min.js"></script>
  </body>
</html>