<?php

$koneksi = mysqli_connect("localhost","root","","db_pinjambuku");

function query($query){
    global $koneksi;
    $result = mysqli_query($koneksi, $query);
    $rows = [];
    while( $row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function hapus($id) {
    global $koneksi;
    mysqli_query($koneksi, "DELETE FROM pinjambuku Where id = $id");
    return mysqli_affected_rows($koneksi);


}

function tambah($data) {
    global $koneksi;
    $nama           =$data["nama"];
    $kelas          =$data["kelas"];
    $tanggal_pinjam =$data["tanggal_pinjam"];
    $judul_buku     =$data["judul_buku"];
    $jumlah_buku    =$data["jumlah_buku"];
    $jenis_buku     =$data["jenis_buku"];
    $telp           =$data["telp"];

    $query = "INSERT INTO pinjambuku VALUES 
    ('', '$nama', '$kelas', '$tanggal_pinjam', '$judul_buku', '$jumlah_buku', '$jenis_buku', '$telp')
  ";
mysqli_query($koneksi, $query);

return mysqli_affected_rows($koneksi);

}

function ubah($data) {
    global $koneksi;

    $id             =$data["id"];
    $nama           =$data["nama"];
    $kelas          =$data["kelas"];
    $tanggal_pinjam =$data["tanggal_pinjam"];
    $judul_buku     =$data["judul_buku"];
    $jumlah_buku    =$data["jumlah_buku"];
    $jenis_buku     =$data["jenis_buku"];
    $telp           =$data["telp"];

    $query = "UPDATE pinjambuku SET 
            nama = '$nama', 
            kelas = '$kelas',
            tanggal_pinjam = '$tanggal_pinjam', 
            judul_buku = '$judul_buku', 
            jumlah_buku = '$jumlah_buku', 
            jenis_buku = '$jenis_buku',
            telp = '$telp'
            WHERE id = $id
                ";
    mysqli_query($koneksi, $query);
    return mysqli_affected_rows($koneksi);

}

function cari($keyword) {
    $query = "SELECT * FROM pinjambuku
                WHERE
                nama LIKE '%$keyword%' OR
                kelas LIKE '%$keyword%' OR
                judul_buku LIKE '%$keyword%'
                ";
                return query($query);
}

function registrasi($data){
    global $koneksi;

    $username = strtolower(stripslashes($data["username"]));
    $password = mysqli_real_escape_string($koneksi,  $data["password"]);
    $password2 = mysqli_real_escape_string($koneksi, $data["password2"]);

    //cek ketersediaan uname
    $result = mysqli_query($koneksi, "SELECT username FROM user 
    WHERE username ='$username'");

    if( mysqli_fetch_assoc($result)){
        echo  "<script>
        alert('gagal! username sudah digunakan');
        </script>";
        return false;
    }

    // cek konfirmasi pass
    if( $password !== $password2 ){
        echo "<script>
        alert('konfirmasi password tidak cocok');
        </script>";
        return false;
    }

    // enkripsi pass
    $password = password_hash($password, PASSWORD_DEFAULT);

    //tambah user baru ke database
    mysqli_query($koneksi, "INSERT INTO user VALUES('', '$username', '$password')");

    return mysqli_affected_rows($koneksi);
}

?>
 