<?php
require 'config.php'

$id = $_GET["id"];

if( hapus($id) > 0) {
    echo "
      <script>
      alert('data dihapus');
      document.location.href = 'data-pinjam.php';
      </script>
      ";
    } else {
        echo "
        <script>
        alert('data gagal dihapus');
        document.location.href = 'data-pinjam.php';
        </script>
        ";
}

?>