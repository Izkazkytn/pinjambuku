<?php
session_start();

if( !isset($_SESSION["login"])) {
  header("Location: login.php");
  exit;
}
require 'config.php'; 
$buku = query("SELECT * FROM pinjambuku");

// untuk cari
if( isset($_POST["cari"])) {
  $buku = cari($_POST["keyword"]);
}
?>

<!doctype html>
<html lang="en">
<?php include 'navbar.php';?>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="DataTables/DataTables-1.10.22/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="DataTables/buttons-1.6.5/css/buttons.bootstrap4.min.css">
    <link href="fontawesome/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="css/sweetalert2.min.css">
    <script defer src="fontawesome/js/all.js"></script>
    <title>Data Peminjaman</title>
  </head>
  <body>
  <div id="none">
      
    <br>
    <div class="card" style="margin-left:auto;margin-right:auto;border-color: #fff;">
      <div class="card-body">
        <div class="table-wrapper">
          <h3 class="card-title"> Website Pengisian Form Pinjam Buku SMKN 4 BOGOR</h3>
          <a href="input-pinjam.php"><button type="button" class="btn btn-primary">Tambah Data</button></a>
          <!--Modal Import -->
          <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Import Data Siswa</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
              <div class="form-group">
            </div>
            </div>
              </div>
              <div class="modal-footer">
                </form>
              </div>
            </div>
          </div>
          </div>
          <!-- End Modal Import -->
          <br><br>
          <form action="" method="post">
           
          <input type="text" name="keyword" class="col-sm-2 col-form-label" size="25"
          placeholder="cari" autocomplete="off">
          <button type="button" class="btn btn-primary">cari</button>
        </form>
          <br>
           
            <thead>
            <div class="table-responsive mt-2">
            <table id="data_pinjam" class="table table-bordered table-hover" 
            style="border-radius: 5px; font-size : 14px; width: 100%;">
              <tr style="text-align: center; height : 25px;">
              <div class="table-responsive mt-2">
        <div class="card">
            <div class="card-header bg-secondary text-white">
            Data Peminjaman Buku
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Kelas</th>
                    <th scope="col">Tanggal Pinjam </th>
                    <th scope="col">Judul Buku</th>
                    <th scope="col">Jumlah Buku</th>
                    <th scope="col">Jenis Buku</th>
                    <th scope="col">Telepon</th>
                    <th scope="col">Aksi</th>
                </tr>

                    <tbody>
                      <?php $no = 1; ?>
                    <?php foreach( $buku as $row ): ?>

                        <tr>
                            <td><?= $no; ?></td>
                            <td><?= $row["nama"]; ?></td>
                            <td><?= $row["kelas"]; ?></td>
                            <td><?= $row["tanggal_pinjam"]; ?></td>
                            <td><?= $row["judul_buku"]; ?></td>
                            <td><?= $row["jumlah_buku"]; ?></td>
                            <td><?= $row["jenis_buku"]; ?></td>
                            <td><?= $row["telp"]; ?></td>
                            <td>
                            <a href="edit-pinjam.php?id=<?= $row["id"]; ?>"><button type="button" class="btn btn-secondary">Edit</button></a>
                            <a href="delete-pinjam.php?id=<?= $row["id"]; ?>"><button type="button" class="btn btn-dark">Delete</button></a>
                            </td>
                            </tr>
                            <?php $no++; ?>
                            <?php endforeach;?>
          </div>
        </div>
    </div>
</body>
</html>

    <script src="js/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <script src="js/jquery-1.12.4.js"></script>
    <script src="DataTables/DataTables-1.10.22/js/jquery.dataTables.min.js"></script>
    <script src="DataTables/DataTables-1.10.22/js/dataTables.bootstrap4.min.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="DataTables/buttons-1.6.5/js/dataTables.buttons.min.js"></script>
    <script src="DataTables/buttons-1.6.5/js/buttons.bootstrap4.min.js"></script>
    <script src="DataTables/jszip-2.5.0/jszip.min.js"></script>
    <script src="DataTables/jszip-2.5.0/jszip.min.js"></script>
    <script src="DataTables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="DataTables/buttons-1.6.5/js/buttons.html5.min.js"></script>
    <script src="DataTables/buttons-1.6.5/js/buttons.print.min.js"></script>
    <script src="DataTables/buttons-1.6.5/js/buttons.colVis.min.js"></script>
    <script src="js/sweetalert2.min.js"></script>
    <script type="text/javascript" language="javascript" >
     
    </script>
</body>
</html>

